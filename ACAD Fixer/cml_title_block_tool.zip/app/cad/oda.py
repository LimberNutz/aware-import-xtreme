import subprocess
import os
import logging
from pathlib import Path

class ODAConverter:
    def __init__(self, exe_path: str):
        self.exe_path = exe_path

    def dwg_to_dxf(self, input_dir: str, output_dir: str, version: str = "ACAD2018"):
        """
        Runs ODA File Converter to convert all DWGs in input_dir to DXF in output_dir.
        """
        logging.info(f"Converting DWG -> DXF in {input_dir}")
        cmd = [
            self.exe_path,
            input_dir,
            output_dir,
            version,
            "DXF",
            "0",  # Recurse: No
            "1",  # Audit: Yes
        ]
        
        try:
            # We use shell=True on Windows but for generic CLI we use list
            result = subprocess.run(cmd, capture_output=True, text=True)
            if result.returncode != 0:
                logging.error(f"ODA Error: {result.stderr}")
            return result.returncode == 0
        except Exception as e:
            logging.error(f"Failed to run ODA: {e}")
            return False

    def dxf_to_dwg(self, input_dir: str, output_dir: str, version: str = "ACAD2018"):
        """
        Runs ODA File Converter to convert all DXFs in input_dir to DWG in output_dir.
        """
        logging.info(f"Converting DXF -> DWG in {input_dir}")
        cmd = [
            self.exe_path,
            input_dir,
            output_dir,
            version,
            "DWG",
            "0",
            "1"
        ]
        return subprocess.run(cmd).returncode == 0
