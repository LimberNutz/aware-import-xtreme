import logging
from typing import Dict

class MaterialClassifier:
    @staticmethod
    def classify(material_grades: str) -> str:
        """
        Classifies material grades into C, SS, or C/SS.
        """
        grades = material_grades.upper()
        
        is_carbon = any(g in grades for g in ["A106", "A234", "CARBON", "WPB"])
        is_ss = any(g in grades for g in ["A312", "A403", "SS", "304", "316", "WP304", "TP304"])
        
        if is_carbon and is_ss:
            return "C/SS"
        if is_carbon:
            return "C"
        if is_ss:
            return "SS"
        
        return "Unknown"

class ODConverter:
    @staticmethod
    def to_nominal(od_str: str) -> str:
        """
        Maps OD to nominal pipe size.
        """
        try:
            val = float(od_str.replace('"', '').strip())
        except ValueError:
            return od_str

        mappings = {
            12.750: "12\"",
            10.750: "10\"",
            8.625: "8\"",
            6.625: "6\"",
            4.500: "4\"",
            3.500: "3\"",
            2.375: "2\"",
            1.315: "1\"",
            1.050: "3/4\"",
            0.840: "1/2\""
        }
        
        return mappings.get(val, f"{val}\"")
