import csv
import logging
from dataclasses import dataclass, field
from typing import List, Optional

@dataclass
class CMLRow:
    pressure: Optional[str] = None
    temperature: Optional[str] = None
    material_grade: str = ""

@dataclass
class AssetRecord:
    equipment_id: str
    equipment_description: str
    year_built: str
    pipe_class: str
    stress_table_used: str
    pid_number: str
    diameter_od: str
    cml_rows: List[CMLRow] = field(default_factory=list)

class GGCSVParser:
    def __init__(self, csv_path: str, asset_id: str):
        self.csv_path = csv_path
        self.asset_id = asset_id

    def parse(self) -> Optional[AssetRecord]:
        logging.info(f"Parsing CSV: {self.csv_path} for Asset: {self.asset_id}")
        
        try:
            with open(self.csv_path, mode='r', encoding='utf-8-sig') as f:
                reader = csv.DictReader(f)
                
                record = None
                collecting = False
                
                for row in reader:
                    eid = row.get('Equipment ID', '').strip()
                    
                    if eid == self.asset_id:
                        collecting = True
                        record = AssetRecord(
                            equipment_id=eid,
                            equipment_description=row.get('Equipment Description', ''),
                            year_built=row.get('Year Built', ''),
                            pipe_class=row.get('Class', ''),
                            stress_table_used=row.get('Stress Table Used', ''),
                            pid_number=row.get('P&ID Number', ''),
                            diameter_od=row.get('CML Outside Diameter', '')
                        )
                        # Add the first row's CML data if present
                        self._add_cml_row(record, row)
                        continue
                        
                    if collecting:
                        if eid != '' and eid != self.asset_id:
                            # Hit another asset, stop
                            break
                        
                        # Child row for the same asset (empty Equipment ID)
                        self._add_cml_row(record, row)
                
                return record
        except Exception as e:
            logging.error(f"Failed to parse CSV: {e}")
            return None

    def _add_cml_row(self, record, row):
        pressure = row.get('CML Pressure', '').strip()
        temp = row.get('CML Temperature', '').strip()
        mat = row.get('Material Grade', '').strip()
        
        if pressure or temp or mat:
            record.cml_rows.append(CMLRow(
                pressure=pressure,
                temperature=temp,
                material_grade=mat
            ))
