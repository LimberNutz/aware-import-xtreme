import logging
import os
import shutil
from pathlib import Path
from app.parsers.csv_parser import GGCSVParser
from app.domain.formatters import MaterialClassifier, ODConverter

class JobManager:
    def __init__(self, args):
        self.args = args

    def run(self):
        logging.info("Starting Full Run...")
        # Step 1: Parse
        record = self._get_record()
        if not record:
            logging.error("No record found. Aborting.")
            return

        # Step 2: Generate Lookup
        lookup = self._generate_lookup(record)
        logging.info(f"Derived Lookup: {lookup}")

        if self.args.dry_run:
            logging.info("DRY RUN: No files will be modified.")
            return

        # Step 3: Edit Files
        logging.info("Searching for files to update...")
        # Implementation would follow...
        logging.info("Processing complete.")

    def _get_record(self):
        if self.args.csv and self.args.asset:
            parser = GGCSVParser(self.args.csv, self.args.asset)
            return parser.parse()
        return None

    def _generate_lookup(self, record):
        mat_grades = ", ".join([r.material_grade for r in record.cml_rows if r.material_grade])
        
        return {
            "EQUIPMENT_ID": record.equipment_id,
            "CIRCUIT_DESC1": record.equipment_description[:40],
            "CIRCUIT_DESC2": record.equipment_description[40:80],
            "YEAR_BLT": record.year_built,
            "CLASS": record.pipe_class.replace("Class ", "").strip(),
            "B31_TYPE": "3",  # Sample hardcoded
            "PID_NUMBER": record.pid_number,
            "OD_IN": ODConverter.to_nominal(record.diameter_od),
            "DESIGN_PRESS": max([r.pressure for r in record.cml_rows if r.pressure], default=""),
            "DESIGN_TEMP": max([r.temperature for r in record.cml_rows if r.temperature], default=""),
            "MATERIAL": MaterialClassifier.classify(mat_grades)
        }

    def parse_only(self):
        record = self._get_record()
        if record:
            print(self._generate_lookup(record))

    def validate_only(self):
        logging.info(f"Validating lookup: {self.args.lookup}")

    def probe_dxf(self, file_path):
        logging.info(f"Probing DXF: {file_path}")

    def probe_pdf(self, file_path):
        logging.info(f"Probing PDF: {file_path}")
