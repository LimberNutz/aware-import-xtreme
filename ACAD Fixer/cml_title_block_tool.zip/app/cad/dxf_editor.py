import ezdxf
import logging
from typing import Dict

class DXFEditor:
    def __init__(self, file_path: str):
        self.file_path = file_path
        self.doc = None

    def load(self):
        try:
            self.doc = ezdxf.readfile(self.file_path)
            return True
        except Exception as e:
            logging.error(f"Failed to load DXF: {e}")
            return False

    def update_attributes(self, mapping: Dict[str, str]):
        """
        Updates block attributes based on tag name mapping.
        """
        if not self.doc:
            return

        msp = self.doc.modelspace()
        for entity in msp.query('INSERT'):
            if entity.has_attrib:
                for attr in entity.attribs:
                    tag = attr.dxf.tag.upper()
                    if tag in mapping:
                        old_val = attr.dxf.text
                        new_val = mapping[tag]
                        attr.dxf.text = new_val
                        logging.info(f"Updated {tag}: '{old_val}' -> '{new_val}'")

    def save(self, output_path: str):
        if self.doc:
            self.doc.saveas(output_path)
            logging.info(f"Saved DXF to: {output_path}")
